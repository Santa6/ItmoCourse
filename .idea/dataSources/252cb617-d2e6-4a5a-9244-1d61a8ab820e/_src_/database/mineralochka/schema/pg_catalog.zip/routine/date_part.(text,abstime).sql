create function date_part(text, abstime) returns double precision
STABLE
LANGUAGE SQL
AS $$
select pg_catalog.date_part($1, cast($2 as timestamp with time zone))
$$;
